<!------------------------------------------------------------------------- FOOTER START------------------------------------------------------------------------->


        <!--Footer Section Start-->
    <footer id="footer">
        

        <div class="footer-bottom-part">
            <div class="container">
                <!--            footer bottom part-->
                <div class="row footer-bt-padding">
                    <div class="col-md-3 col-sm-12">
                        <div class="fb-left">
                           <h2>social link</h2>
                           <div class="center">
                             <div id="social-test">
                                <ul class="social mb-10">
                                  <div class="social-left">
                            
                                   <li><i class="fa fa-facebook" aria-hidden="true"></i></li>
                                   <li><i class="fa fa-twitter" aria-hidden="true"></i></li>
                                   <li><i class="fa fa-youtube" aria-hidden="true"></i></li>
                                   <li><i class="fa fa-github" aria-hidden="true"></i></li>
                                    <li><i class="fa fa-google" aria-hidden="true"></i></li>
                                   <li><i class="fa  fa-google-plus" aria-hidden="true"></i></li>
                                    </div>
                                </ul>
                               
                             </div>
                          </div>
                        </div>
                    </div>
                    <div class="col-md-4 offset-md-1 offset-sm-0 col-sm-12">
                        <div class="fb-mid">
                            <h5>Quick Link</h5>
                            <ul>
                                <li><a href="#home">Home</a></li>
                                <li><a href="#about">ABOUT</a></li>
                                <li><a href="#portfolio">Portfolio</a></li>
                                <li><a href="#skills">Skill</a></li>
                                <li><a href="#client-blogs">client says</a></li>
                                <li><a href="#contact">Contact</a></li>
                                <li><a href="blood-doner-list">all doner</a></li>
                                <li><a href="blood-registrasion">registrasion</a></li>
                                  <li><a href="all-blogs">blog</a></li>
                                <li></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3 offset-md-0 offset-sm-0 col-sm-12 address">
                        <div class="fb-last">
                            <h5>Contact Info</h5>
                            <ul>
                                <li><span>Phone : </span> +8801683392241,01738202364</li>
                                <li><span>Email : </span></a> rupomehsan34@gmail.com</li>
                                <li><span>Email : </span></a> rupomehsan55@yahoo.com</li>
                                <li><span>Address : </span> DHAKA, BANGLADESH</li>
                            </ul>
                        </div>
                    </div>

                </div>
            </div>
            <div class="bottomf">
                <div class="row">
                    <div class="col-12">
                        <p>Copyright &copy; 2020 RUPOMEHSAN</p>
                    </div>
                </div>
            </div>

        </div>
    </footer>

    <!-- ---------------------------------------------------------   footer part end-------------------------------------------------------------->








      <!-- BACK TO TOP --><a href="#home1" class="backtop"><i class="fa fa-chevron-up" aria-hidden="true"></i> </a>

      <!--------------------------------------------------------- Javascripts --------------------------------->
      <script src="js/jquery-2.1.4.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <script src="js/scrolling-parallax.js"></script>
      <script src="js/owl.carousel.min.js"></script>
      <script src="venobox/venobox.min.js"></script>
      <script src="js/modernizr.custom.js"></script>
      <script src="js/main.js"></script>
    <!--   <script src="js/main2.js"></script> -->
    <!--   <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
      <script type="text/javascript"> -->

    <script>(function(d, s, id) {
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) return;
      js = d.createElement(s); js.id = id;
      js.src = "https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v3.0";
      fjs.parentNode.insertBefore(js, fjs);
      }(document, 'script', 'facebook-jssdk'));
</script>

      <!--------------------------------------------------------- Javascripts --------------------------------->
   </body>

</html>

<?php

define('DB_HOST', 'localhost');
define('DB_NAME', 'mdrupome_blood_management');
define('DB_USER', 'mdrupome_rupomeh');
define('DB_PASS', 'K$_1iCg(21c+');


?>